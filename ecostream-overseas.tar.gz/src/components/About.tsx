import { Target, Globe, Users } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-20 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: 'url(https://images.pexels.com/photos/1098515/pexels-photo-1098515.jpeg?auto=compress&cs=tinysrgb&w=1920)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      ></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">About Us</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8"></div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Ecostream Overseas is a trusted study abroad consultancy dedicated to helping students achieve their dream
            of studying internationally. We provide expert guidance and complete support for students who want to study
            in top global destinations.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div className="overflow-hidden rounded-2xl shadow-2xl transform hover:scale-105 transition-transform duration-500">
            <img
              src="https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Consultation"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="space-y-6">
            <h3 className="text-3xl font-bold text-gray-900 mb-6">Our Vision & Mission</h3>
            <p className="text-gray-600 leading-relaxed text-lg">
              We are committed to guiding students and professionals through every step of their journey — from
              selecting the right university or job opportunity to completing documentation and visa procedures. Our
              goal is to make the entire process simple, transparent, and successful.
            </p>
            <div className="flex items-start space-x-4 pt-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Target className="text-blue-600" size={28} />
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2 text-lg">Expert Guidance</h4>
                <p className="text-gray-600">
                  Professional counseling tailored to your academic goals and career aspirations
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Globe className="text-blue-600" size={28} />
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2 text-lg">Global Reach</h4>
                <p className="text-gray-600">
                  Access to top universities in USA, UK, Australia, Cyprus, France, and Malta
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Users className="text-blue-600" size={28} />
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2 text-lg">End-to-End Support</h4>
                <p className="text-gray-600">Complete assistance from application to visa approval</p>
              </div>
            </div>
            <button className="mt-6 bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105">
              Read More
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
