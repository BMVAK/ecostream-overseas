import { Quote, ChevronLeft, ChevronRight } from 'lucide-react';

export default function Testimonials() {
  const testimonials = [
    {
      name: 'Rajesh Kumar',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=200',
      text: 'Ecostream Overseas made my dream of studying in the UK a reality. Their professional guidance and support throughout the visa process was exceptional.',
      destination: 'UK',
    },
    {
      name: 'Priya Sharma',
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=200',
      text: 'Thank you for helping me get admission to my dream university in Australia. The team was very supportive and made the entire process hassle-free.',
      destination: 'Australia',
    },
    {
      name: 'Arun Patel',
      image: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=200',
      text: 'Excellent service! They helped me secure a work permit in France. Highly recommended for anyone looking to study or work abroad.',
      destination: 'France',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">What Our Clients Say</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8"></div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Success stories from students who achieved their dreams
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100 relative"
            >
              <div className="absolute -top-4 left-8 bg-blue-600 w-12 h-12 rounded-full flex items-center justify-center">
                <Quote className="text-white" size={24} />
              </div>
              <div className="flex flex-col items-center mb-6 mt-4">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-20 h-20 rounded-full object-cover mb-4 border-4 border-blue-100"
                />
                <h4 className="text-xl font-bold text-gray-900">{testimonial.name}</h4>
                <p className="text-blue-600 font-medium">{testimonial.destination}</p>
              </div>
              <p className="text-gray-600 leading-relaxed text-center italic">"{testimonial.text}"</p>
            </div>
          ))}
        </div>

        <div className="flex justify-center items-center space-x-3 mt-12">
          <button className="bg-gray-200 hover:bg-gray-300 p-2 rounded-full transition-colors duration-200">
            <ChevronLeft size={20} />
          </button>
          <div className="flex space-x-2">
            <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
            <div className="w-3 h-3 bg-gray-300 rounded-full"></div>
            <div className="w-3 h-3 bg-gray-300 rounded-full"></div>
          </div>
          <button className="bg-gray-200 hover:bg-gray-300 p-2 rounded-full transition-colors duration-200">
            <ChevronRight size={20} />
          </button>
        </div>
      </div>
    </section>
  );
}
