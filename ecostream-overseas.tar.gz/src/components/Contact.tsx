import { MapPin, Phone, Mail, Facebook, Twitter, Instagram, Linkedin, Youtube, MessageCircle } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Get In Touch</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8"></div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Have questions? We're here to help you start your journey
          </p>
        </div>

        <div className="flex justify-center space-x-6 mb-16">
          <a
            href="#"
            className="bg-blue-600 hover:bg-blue-700 text-white w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 transform hover:scale-110 shadow-lg"
          >
            <Facebook size={24} />
          </a>
          <a
            href="#"
            className="bg-sky-500 hover:bg-sky-600 text-white w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 transform hover:scale-110 shadow-lg"
          >
            <Twitter size={24} />
          </a>
          <a
            href="#"
            className="bg-pink-600 hover:bg-pink-700 text-white w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 transform hover:scale-110 shadow-lg"
          >
            <Instagram size={24} />
          </a>
          <a
            href="#"
            className="bg-green-600 hover:bg-green-700 text-white w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 transform hover:scale-110 shadow-lg"
          >
            <MessageCircle size={24} />
          </a>
          <a
            href="#"
            className="bg-blue-700 hover:bg-blue-800 text-white w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 transform hover:scale-110 shadow-lg"
          >
            <Linkedin size={24} />
          </a>
          <a
            href="#"
            className="bg-red-600 hover:bg-red-700 text-white w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 transform hover:scale-110 shadow-lg"
          >
            <Youtube size={24} />
          </a>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-gradient-to-br from-blue-50 to-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-blue-100">
            <div className="bg-blue-600 w-14 h-14 rounded-full flex items-center justify-center mb-6">
              <MapPin className="text-white" size={28} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-4">Our Branches</h3>
            <div className="space-y-4">
              <div>
                <p className="font-semibold text-gray-900 mb-1">Guntur Office</p>
                <p className="text-gray-600 leading-relaxed">
                  Koritepadu 5th Line, Guntur, Andhra Pradesh, India
                </p>
              </div>
              <div className="pt-4 border-t border-gray-200">
                <p className="font-semibold text-gray-900 mb-1">Hyderabad Office</p>
                <p className="text-gray-600 leading-relaxed">KPHB Phase-2, Hyderabad, Telangana, India</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-green-50 to-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-green-100">
            <div className="bg-green-600 w-14 h-14 rounded-full flex items-center justify-center mb-6">
              <Phone className="text-white" size={28} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-4">Phone Numbers</h3>
            <div className="space-y-3">
              <a
                href="tel:+919876543210"
                className="block text-gray-600 hover:text-green-600 transition-colors duration-200 text-lg"
              >
                +91 98765 43210
              </a>
              <a
                href="tel:+919876543211"
                className="block text-gray-600 hover:text-green-600 transition-colors duration-200 text-lg"
              >
                +91 98765 43211
              </a>
            </div>
            <p className="text-sm text-gray-500 mt-4">Available: Mon - Sat, 9:00 AM - 6:00 PM</p>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-purple-100">
            <div className="bg-purple-600 w-14 h-14 rounded-full flex items-center justify-center mb-6">
              <Mail className="text-white" size={28} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-4">Email</h3>
            <a
              href="mailto:info@ecostreamoverseas.com"
              className="text-gray-600 hover:text-purple-600 transition-colors duration-200 text-lg break-words"
            >
              info@ecostreamoverseas.com
            </a>
            <p className="text-sm text-gray-500 mt-4">We typically respond within 24 hours</p>
          </div>
        </div>

        <div className="mt-16 bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-12 text-center text-white shadow-2xl">
          <h3 className="text-3xl font-bold mb-4">Ready to Start Your Journey?</h3>
          <p className="text-xl mb-8 text-white/90">
            Book a free consultation with our expert counselors today
          </p>
          <button className="bg-white text-blue-600 hover:bg-gray-100 px-10 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105">
            Schedule Consultation
          </button>
        </div>
      </div>
    </section>
  );
}
